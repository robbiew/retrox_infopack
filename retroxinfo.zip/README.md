
# RetroX Network InfoPack
-= Fidonet-Based Network for Bulliten Board Systems (BBS) =-

RetroX is a global echomail network devoted to discussing all things "retro." What kinds of things? Computers, Media (e.g. movies, music -- even modern videos, podcasts related to "reto" things), games, culture and design.

> *In popular culture, the "nostalgia cycle" is typically for the two decades that are 20–30 years before the current one.* -Wikipedia

Refer to [retrox.na](retrox.na) for an areas list, [retrox.txt](retrox.txt) for general info and [join.txt](join.txt) for information on joining.




